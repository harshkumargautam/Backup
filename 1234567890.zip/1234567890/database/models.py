from django.db import models
from django.core.exceptions import ValidationError
from django.core.validators import MinValueValidator, MaxValueValidator
from phone_field import PhoneField


class Subjects(models.Model):
    subject = models.CharField(max_length = 100, default="")

    def __str__(self):
        return self.subject


class QuestionsBank(models.Model):

    question_text_english = models.CharField(max_length = 1000, default="")
    question_text_hindi = models.CharField(max_length = 1000, default="") 
    question_image = models.ImageField(upload_to = 'database/media', blank=True)
    
    subject = models.ForeignKey(Subjects, on_delete = models.CASCADE)

    option1_text_english = models.CharField(max_length=1000, default="")
    option1_text_hindi = models.CharField(max_length=1000, default="")
    option1_image = models.ImageField(upload_to='database/media', blank=True)

    option2_text_englsih = models.CharField(max_length=1000, default="")
    option2_text_hindi = models.CharField(max_length=1000, default="")
    option2_image = models.ImageField(upload_to='database/media', blank=True)

    option3_text_english = models.CharField(max_length=1000, default="")
    option3_text_hindi = models.CharField(max_length=1000, default="")
    option3_image = models.ImageField(upload_to='database/media', blank=True)

    option4_text_english = models.CharField(max_length=1000, default="")
    option4_text_hindi = models.CharField(max_length=1000, default="")
    option4_image = models.ImageField(upload_to='database/media', blank=True)


    Answer = models.CharField(max_length= 1, null = True, choices= (('1', '1'),
                                                                    ('2', '2'),
                                                                    ('3', '3'),
                                                                    ('4', '4')))

    def __str__(self):
        return self.question_text_english

class CglTier1TestSeries(models.Model):
    
    question1 = models.ForeignKey(QuestionsBank, on_delete = models.CASCADE, related_name = "A")
    question2 = models.ForeignKey(QuestionsBank, on_delete = models.CASCADE, related_name = "B")
    question3 = models.ForeignKey(QuestionsBank, on_delete = models.CASCADE, related_name = "C")
    question4 = models.ForeignKey(QuestionsBank, on_delete = models.CASCADE, related_name = "D")

