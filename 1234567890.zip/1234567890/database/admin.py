from django.contrib import admin
from .models import Subjects, QuestionsBank, CglTier1TestSeries

# Register your models here.

admin.site.register(CglTier1TestSeries)
admin.site.register(Subjects)
admin.site.register(QuestionsBank)


