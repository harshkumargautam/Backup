from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver

# Create your models here.

class Profile(models.Model):

    user=models.OneToOneField(User, on_delete=models.CASCADE)
    name=models.CharField(max_length=40)
    phone=models.CharField(max_length=13)
    wallet=models.IntegerField(default=0)
    picture=models.ImageField(upload_to="", blank=True)
    is_email_verified=models.BooleanField(default=False)
    is_number_verified=models.BooleanField(default=False)
    category=models.CharField(max_length=5, default="SC", choices=(('UR', 'UR'),
                                                                     ('EWS', 'EWS'),
                                                                     ('OBC', 'OBC'),
                                                                     ('SC', 'SC'),
                                                                     ('ST', 'ST')))
    language=models.CharField(max_length=10, default='English', choices=(("English", "English"),
                                                                         ("हिंदी", "हिंदी")))
    def __str__(self):
        return self.name


@receiver(post_save, sender=User)
def update_profile_signal(sender, instance, created, **kwargs):
    if created:
        Profile.objects.create(user=instance)
    instance.profile.save()
